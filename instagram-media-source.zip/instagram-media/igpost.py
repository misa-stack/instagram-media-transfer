#!/usr/bin/env python3
"""Source launcher; uses the adjacent virtual environment when present."""

import os
import sys
from pathlib import Path


def main():
    root = Path(__file__).resolve().parent
    venv = root / ".venv"
    python = venv / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
    if python.is_file() and Path(sys.prefix).resolve() != venv.resolve():
        os.execv(str(python), [str(python), str(root / "igpost.py"), *sys.argv[1:]])
    sys.path.insert(0, str(root / "src"))
    try:
        from igmanager.quickpost import main as quickpost
    except ModuleNotFoundError as error:
        print(
            f"Missing dependency: {error.name}. From {root}, install with: uv sync",
            file=sys.stderr,
        )
        print(
            "Or: python3 -m venv .venv && .venv/bin/python -m pip install -e .",
            file=sys.stderr,
        )
        return 1
    return quickpost()


if __name__ == "__main__":
    raise SystemExit(main())
