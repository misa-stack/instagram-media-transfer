# IGManager

Publish local sensor graphs to Instagram from a terminal. Uses your existing
System User token and GitHub → Cloudflare Pages image hosting.

## Run

Python 3.11+, Git, and working GitHub push authentication are required.
From this folder:

```sh
uv sync
uv run igmanager
```

Or without uv:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -e .
.venv/bin/igmanager
```

No arguments opens the menu. First choose **Manage accounts → Add**. The defaults
are `rpiteplomer`, ID `17841437005937020`, Graph API `v26.0`. Paste your working
System User token at the hidden prompt and choose a vault passphrase. The token
must have access to that Instagram professional account and publishing permission;
the tool does not create accounts or grant Meta permissions. Keep the API version
aligned with the version supported by your Meta app.

Choose **Post images**, enter absolute paths one at a time (spaces and quoted
paths work), finish with an empty line, optionally reorder/remove slides, then
enter the caption. Finish the caption with a line containing just `.`. Review and
confirm with `y`. Ctrl+C cancels.

One image makes a normal feed post; 2–10 make one ordered swipeable carousel.
JPEG, PNG and WebP inputs become 1080×1080 JPEG copies with white padding so
labels are not cropped. Originals are untouched; metadata is stripped.

## One Bash command

After the one-time installation above, use the source launcher directly:

```sh
# No arguments opens the menu to save your account and token.
python3 igpost.py

# One image and its caption:
python3 igpost.py /absolute/path/temperature.png "Temperature today"

# Multiple images become one carousel; the last argument is always the caption:
python3 igpost.py /absolute/path/temperature.png /absolute/path/humidity.png "Today's readings"

# Select an account when more than one is saved:
python3 igpost.py --account sensor /absolute/path/temperature.png "Room sensor"
```

Quote paths containing spaces and always quote the caption. Use `""` for no caption.
This shortcut publishes immediately, including the Git commit and push, without
asking for another confirmation. It uses your only saved account unless you pass
`--account`. The encrypted vault still needs its passphrase: enter it at the prompt,
or supply `IGMANAGER_PASSPHRASE` in the environment for unattended runs.
The launcher automatically uses the `.venv` next to it if present. You can invoke
it from anywhere with `python3 /absolute/path/to/igpost.py ...`; configure the
hosting repository once with `igmanager configure --repo ...` if necessary.

## Hosting

The defaults are the current Git checkout (falling back to this source checkout), `origin/main`, and
`https://instagram-media.pages.dev`. GitHub must already be connected to Cloudflare
Pages with automatic production deployments from `main`, a blank build command,
and the repository root as output directory, as in your existing setup.

Each confirmed post commits **only** generated files in `media/<unique-id>/`,
pushes them, and waits up to ten minutes until the public URLs return the exact
image bytes. The repository must be on `main`, have no staged changes, and match
`origin/main` before posting. Unrelated unstaged changes are preserved. Sync or
resolve Git errors manually; no force pushes, resets, or automatic merges happen.
Images stay in Git and on Cloudflare after posting. They are publicly accessible.

If you installed the package outside this checkout, configure the hosting repo:

```sh
igmanager configure --repo /absolute/path/to/instagram-media
igmanager configure --hosting-url https://instagram-media.pages.dev --api-version v26.0
```

The application source can live in this repo alongside the hosted JPEG files.
If you commit application changes locally, push those commits before posting;
the hosting guard blocks a local branch ahead of origin/main. Uncommitted source
changes are left untouched and are not included in image commits.

## Direct commands

Use `uv run igmanager` instead of `igmanager` when running via uv.

```sh
igmanager accounts add rpiteplomer --ig-id 17841437005937020
igmanager accounts list
igmanager accounts edit rpiteplomer --name sensor --info "Room sensor"
igmanager accounts token sensor
igmanager status sensor
igmanager post sensor /absolute/path/temperature.png --caption "Today's temperature"
igmanager post sensor /absolute/path/temp.png /absolute/path/humidity.png --caption-file caption.txt
igmanager history
igmanager reconcile ACTION_ID_FROM_HISTORY
igmanager accounts remove sensor
```

`post --yes` confirms both Git hosting and Instagram publication for scripts.
For scripts use `IGMANAGER_PASSPHRASE` and `accounts add/token --token-file PATH`
(or `--token-file -` for stdin). Tokens are never command-line arguments. An empty
caption is allowed; captions are limited to 2,200 characters.

## Storage and recovery

Tokens are encrypted with a passphrase-derived Scrypt key and Fernet, following
FBManager's storage implementation. A separate local SQLite database stores
account metadata, settings and history. On Linux it is under
`$XDG_DATA_HOME/igmanager` or `~/.local/share/igmanager`; on Windows it is under
`%LOCALAPPDATA%/IGManager`. `IGMANAGER_HOME` overrides that location. Never put it
inside the public hosting repository. Keep your passphrase; there is no reset
that recovers encrypted tokens.

If an operation fails, inspect **History**. Image paths, container IDs and completed
stages remain saved. A publish timeout is recorded as `publish_uncertain` and is
never automatically retried. **Check pending post** / `reconcile` reads the stored
parent container status without publishing again. `PUBLISHED` marks the action
published; otherwise check Instagram itself before starting another post. Hard
interruptions may leave an earlier stage recorded. Reconciliation does not repost
or resume incomplete uploads. If publishing succeeded but link lookup failed, the
post ID still appears in history.

## Development

```sh
uv sync --group dev
uv run pytest -q
uv run ruff check src tests
```

Tests use mocked Instagram/HTTP responses and temporary local Git remotes. They do
not prove live Meta permissions or a successful real Instagram publication.
