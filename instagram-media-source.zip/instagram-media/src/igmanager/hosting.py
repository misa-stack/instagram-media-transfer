"""Push only generated media and verify the exact deployed bytes."""

import hashlib
import os
import subprocess
import time
from contextlib import contextmanager
from pathlib import Path
from urllib.parse import quote, urlparse

import httpx

from . import storage


class Hosting:
    def __init__(self, root: Path, base: str, *, http=None):
        self.root = root.resolve()
        if urlparse(base).scheme != "https" or not urlparse(base).hostname:
            raise ValueError("Hosting URL must use HTTPS.")
        self.base = base.rstrip("/")
        self.http = http or httpx.Client(timeout=20, follow_redirects=True)

    def close(self):
        self.http.close()

    def git(self, *args):
        result = subprocess.run(
            ["git", "-C", str(self.root), *args],
            check=False,
            capture_output=True,
            text=True,
        )
        if result.returncode:
            # Avoid exposing authenticated remote URLs in git stderr.
            raise ValueError(
                f"Git {args[0]} failed. Check Git authentication, remote and branch manually."
            )
        return result.stdout.strip()

    def preflight(self):
        if self.git("branch", "--show-current") != "main":
            raise ValueError("Switch the image hosting repository to main first.")
        if self.git("diff", "--cached", "--name-only"):
            raise ValueError(
                "Repository has staged changes. Commit or unstage them first."
            )
        self.git("fetch", "origin", "main")
        if self.git("rev-parse", "HEAD") != self.git("rev-parse", "origin/main"):
            raise ValueError(
                "Local main differs from origin/main. Synchronize it manually first."
            )

    def urls(self, paths):
        return [
            f"{self.base}/{quote(p.resolve().relative_to(self.root).as_posix())}"
            for p in paths
        ]

    @contextmanager
    def lock(self):
        lock_path = Path(self.git("rev-parse", "--git-path", "igmanager-hosting.lock"))
        if not lock_path.is_absolute():
            lock_path = self.root / lock_path
        fd = os.open(lock_path, os.O_CREAT | os.O_RDWR, 0o600)
        try:
            try:
                if storage.IS_WINDOWS:
                    if os.fstat(fd).st_size == 0:
                        os.write(fd, b"\0")
                    os.lseek(fd, 0, os.SEEK_SET)
                    storage.msvcrt.locking(fd, storage.msvcrt.LK_NBLCK, 1)
                else:
                    storage.fcntl.flock(
                        fd, storage.fcntl.LOCK_EX | storage.fcntl.LOCK_NB
                    )
            except OSError:
                raise ValueError(
                    "Another post is using this hosting repository. Wait for it to finish."
                ) from None
            yield
        finally:
            os.close(fd)

    def push(self, paths):
        with self.lock():
            self._push(paths)

    def _push(self, paths):
        self.preflight()
        relative = [p.resolve().relative_to(self.root).as_posix() for p in paths]
        if any(not p.startswith("media/") for p in relative):
            raise ValueError("Only prepared files inside media/ can be committed.")
        self.git("add", "--", *relative)
        self.git("commit", "-m", "Add Instagram post images", "--", *relative)
        self.git("push", "origin", "HEAD:main")

    def wait(self, paths, timeout=600, interval=3):
        deadline = time.monotonic() + timeout
        pending = dict(
            zip(
                self.urls(paths),
                [hashlib.sha256(p.read_bytes()).digest() for p in paths],
            )
        )
        while pending:
            for url, expected in list(pending.items()):
                try:
                    response = self.http.get(url, headers={"Cache-Control": "no-cache"})
                    if (
                        response.status_code == 200
                        and hashlib.sha256(response.content).digest() == expected
                    ):
                        del pending[url]
                except httpx.HTTPError:
                    pass
            if not pending:
                return
            if time.monotonic() >= deadline:
                raise ValueError(
                    "Cloudflare deployment timed out. Images remain saved; check deployment and history."
                )
            time.sleep(interval)
