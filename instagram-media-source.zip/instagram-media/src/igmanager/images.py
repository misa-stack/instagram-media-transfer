"""Prepare graph images on identical square canvases without cropping."""

from pathlib import Path

from PIL import Image, ImageOps


def prepare(paths: list[Path], output: Path) -> list[Path]:
    if not 1 <= len(paths) <= 10:
        raise ValueError("Choose between 1 and 10 images.")
    # Validate every source before writing anything.
    for path in paths:
        if not path.is_absolute() or not path.is_file():
            raise ValueError(f"Image must be an existing absolute file path: {path}")
        if path.suffix.lower() not in {".jpg", ".jpeg", ".png", ".webp"}:
            raise ValueError(f"Unsupported image format: {path.name}")
        with Image.open(path) as im:
            im.verify()
    output.mkdir(parents=True, exist_ok=False)
    prepared = []
    for index, path in enumerate(paths, 1):
        with Image.open(path) as source:
            im = ImageOps.exif_transpose(source).convert("RGBA")
            im.thumbnail((1080, 1080), Image.Resampling.LANCZOS)
            canvas = Image.new("RGB", (1080, 1080), "white")
            canvas.paste(im, ((1080 - im.width) // 2, (1080 - im.height) // 2), im)
            target = output / f"{index:02}.jpg"
            canvas.save(target, "JPEG", quality=95, optimize=True)
            prepared.append(target)
    return prepared
