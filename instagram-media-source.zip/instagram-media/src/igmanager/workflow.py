"""Durable publishing stages. Never automatically retry media_publish."""

import json


def publish(store, account, paths, caption, host, graph, progress=lambda message: None):
    with store.lock(account):
        action = store.begin_action(account, "post", None, caption)
        state = {"paths": [str(p) for p in paths], "containers": []}
        stage = "hosting"

        def save(container):
            state["containers"].append(container)
            store.update_action(action, "processing", result=state)

        try:
            store.update_action(action, stage, result=state)
            progress("Committing and pushing images…")
            host.push(paths)
            progress("Waiting for Cloudflare deployment…")
            host.wait(paths)
            state["urls"] = host.urls(paths)
            progress("Preparing Instagram media…")
            state["parent"] = graph.create(
                account["page_id"], state["urls"], caption, save
            )
            stage = "publish_uncertain"
            store.update_action(action, stage, result=state)
            progress("Publishing to Instagram…")
            state["media_id"] = graph.publish(account["page_id"], state["parent"])
            stage = "published"
            store.update_action(action, stage, result=state)
            try:
                state["permalink"] = graph.permalink(state["media_id"])
            except ValueError:
                pass
            store.update_action(action, stage, result=state)
            return state
        except (Exception, KeyboardInterrupt):
            store.update_action(
                action,
                stage if stage in {"publish_uncertain", "published"} else "failed",
                result=state,
                error="Operation interrupted or failed. Inspect stored progress.",
            )
            raise


def reconcile(store, action, graph):
    state = action["result"] or {}
    if not state.get("parent"):
        raise ValueError(
            "No final container recorded. This action has not reached publishing."
        )
    status = graph.status(state["parent"])
    if status.get("status_code") == "PUBLISHED":
        store.update_action(action["id"], "published", result=state)
    return status


def find_action(store, action_id):
    row = store.db.execute("SELECT * FROM actions WHERE id=?", (action_id,)).fetchone()
    if row is None:
        raise ValueError("History action not found.")
    action = dict(row)
    action["result"] = json.loads(action["result"]) if action["result"] else {}
    return action
