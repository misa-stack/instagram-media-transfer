"""Interactive menu and scriptable commands for Instagram publishing."""

import argparse
import getpass
import json
import os
import shlex
import sqlite3
import subprocess
import sys
import warnings
from pathlib import Path
from uuid import uuid4

from rich.console import Console
from rich.table import Table

from .graph import GraphClient
from .hosting import Hosting
from .images import prepare
from .storage import Store
from .workflow import find_action, publish, reconcile

console = Console(markup=False, highlight=False)


def discover_repo(start=None):
    start = Path(start or Path.cwd()).resolve()
    result = subprocess.run(
        ["git", "-C", str(start), "rev-parse", "--show-toplevel"],
        check=False,
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        return result.stdout.strip()
    source_root = Path(__file__).resolve().parents[2]
    if (source_root / ".git").exists():
        return str(source_root)
    return str(start)


def secret(prompt):
    if not sys.stdin.isatty():
        raise ValueError(
            "Secret input requires a terminal; use a token file and IGMANAGER_PASSPHRASE for scripts."
        )
    with warnings.catch_warnings():
        warnings.simplefilter("error", getpass.GetPassWarning)
        try:
            return getpass.getpass(prompt)
        except getpass.GetPassWarning:
            raise ValueError(
                "Hidden token input is unavailable in this terminal. Use --token-file."
            ) from None


def unlock(store):
    if store.cipher is not None:
        return
    new = store.setting("vault_salt") is None
    password = os.environ.get("IGMANAGER_PASSPHRASE")
    if password is None:
        password = secret("New vault passphrase: " if new else "Vault passphrase: ")
        if new and password != secret("Repeat vault passphrase: "):
            raise ValueError("Passphrases do not match.")
    store.unlock(password, create=True)


def settings(store):
    return {
        "repo": store.setting("repo") or discover_repo(),
        "hosting_url": store.setting("hosting_url")
        or "https://instagram-media.pages.dev",
        "api_version": store.setting("api_version") or "v26.0",
    }


def graph_for(store, account):
    unlock(store)
    return GraphClient(store.token(account), settings(store)["api_version"])


def choose_account(store):
    accounts = store.list_accounts()
    if not accounts:
        console.print("Add your first Instagram account.")
        add_account(store)
        accounts = store.list_accounts()
    if len(accounts) == 1:
        console.print(f"Account: @{accounts[0]['page_name']} ({accounts[0]['name']})")
        return accounts[0]
    for a in accounts:
        console.print(f"{a['name']}: @{a['page_name']}")
    return store.account(input("Account nickname: ").strip())


def token_input(filename=None):
    if filename:
        return (
            sys.stdin.read() if filename == "-" else Path(filename).read_text()
        ).strip()
    token = secret("System User access token (hidden): ").strip()
    if not token:
        raise ValueError("Token cannot be empty.")
    return token


def add_account(store, name=None, account_id=None, token_file=None):
    name = name or input("Local nickname [rpiteplomer]: ").strip() or "rpiteplomer"
    account_id = (
        account_id
        or input("Instagram account ID [17841437005937020]: ").strip()
        or "17841437005937020"
    )
    token = token_input(token_file)
    client = GraphClient(token, settings(store)["api_version"])
    try:
        profile = client.profile(account_id)
    finally:
        client.close()
    unlock(store)
    store.add(name, "", account_id, profile.get("username", account_id), token)
    console.print(f"Saved {name}.")


def multiline():
    console.print("Caption (multiple lines; finish with a line containing only .):")
    lines = []
    while True:
        line = input()
        if line == ".":
            return "\n".join(lines)
        lines.append(line)


def image_prompt():
    paths = []
    console.print("Enter absolute image paths one at a time. Empty line finishes.")
    while True:
        line = input(f"Image {len(paths) + 1}: ").strip()
        if not line:
            break
        # Accept a quoted path pasted from the shell, including spaces.
        if line[:1] in {'"', "'"}:
            parts = shlex.split(line)
            if len(parts) != 1:
                raise ValueError("Enter one image path per line.")
            line = parts[0]
        paths.append(Path(line).expanduser())
    while paths:
        for i, p in enumerate(paths, 1):
            console.print(f"{i}. {p}")
        command = input("Enter to continue, remove N, or move N M: ").strip().split()
        if not command:
            break
        try:
            if command[0] == "remove" and len(command) == 2:
                index = int(command[1])
                if not 1 <= index <= len(paths):
                    raise ValueError()
                paths.pop(index - 1)
            elif command[0] == "move" and len(command) == 3:
                old, new = map(int, command[1:])
                if not (1 <= old <= len(paths) and 1 <= new <= len(paths)):
                    raise ValueError()
                paths.insert(new - 1, paths.pop(old - 1))
            else:
                raise ValueError()
        except ValueError:
            console.print("Use remove N or move N M with valid image numbers.")
    return paths


def post(store, account, paths, caption, yes=False):
    if len(caption) > 2200:
        raise ValueError("Caption exceeds 2,200 characters.")
    cfg = settings(store)
    console.print(f"Publish as @{account['page_name']}; hosting: {cfg['hosting_url']}")
    for index, path in enumerate(paths, 1):
        console.print(f"{index}. {path}")
    console.print(f"Caption:\n{caption}")
    console.print(
        "Images will be padded to square JPEGs, committed, pushed, and published."
    )
    if not yes and input("Publish? [y/N]: ").strip().lower() != "y":
        console.print("Cancelled.")
        return
    client = graph_for(store, account)
    host = Hosting(Path(cfg["repo"]), cfg["hosting_url"])
    try:
        client.profile(account["page_id"])
        host.preflight()
        paths = prepare(paths, host.root / "media" / uuid4().hex)
        result = publish(store, account, paths, caption, host, client, console.print)
        console.print("Published: " + (result.get("permalink") or result["media_id"]))
    finally:
        host.close()
        client.close()


def list_accounts(store):
    table = Table("Nickname", "Instagram", "ID", "Notes")
    for a in store.list_accounts():
        table.add_row(a["name"], "@" + a["page_name"], a["page_id"], a["info"])
    console.print(table)


def history(store, account=None):
    table = Table("Action ID", "Account", "Status", "Post / container")
    for a in store.history(account, limit=50):
        result = a["result"] or {}
        table.add_row(
            a["id"],
            a["account"],
            a["status"],
            result.get("permalink")
            or result.get("media_id")
            or result.get("parent", ""),
        )
    console.print(table)


def account_menu(store):
    while True:
        console.print(
            "\nAccounts: 1 Add  2 List  3 Edit  4 Replace token  5 Remove  0 Back"
        )
        choice = input("> ").strip()
        if choice == "0":
            return
        if choice == "1":
            add_account(store)
        elif choice == "2":
            list_accounts(store)
        elif choice in {"3", "4", "5"}:
            account = choose_account(store)
            unlock(store)
            if choice == "3":
                name = (
                    input(f"Nickname [{account['name']}]: ").strip() or account["name"]
                )
                info = input(f"Notes [{account['info']}]: ").strip() or account["info"]
                store.edit(account["name"], name, info)
            elif choice == "4":
                replace_token(store, account)
            elif (
                input("Remove saved account, token and local history? [y/N]: ").lower()
                == "y"
            ):
                store.remove(account["name"])


def replace_token(store, account, filename=None):
    token = token_input(filename)
    client = GraphClient(token, settings(store)["api_version"])
    try:
        profile = client.profile(account["page_id"])
    finally:
        client.close()
    unlock(store)
    store.edit(
        account["name"], None, None, token=token, page_name=profile.get("username")
    )


def check(store, account):
    client = graph_for(store, account)
    try:
        console.print(
            json.dumps(client.profile(account["page_id"]), ensure_ascii=False)
        )
    finally:
        client.close()


def configure(store):
    for key, default in settings(store).items():
        value = input(f"{key} [{default}]: ").strip()
        if value:
            store.set_setting(key, value)


def reconcile_action(store, action_id):
    action = find_action(store, action_id)
    row = store.db.execute(
        "SELECT name FROM pages WHERE id=?", (action["account_id"],)
    ).fetchone()
    account = store.account(row[0])
    client = graph_for(store, account)
    try:
        with store.lock(account):
            console.print(reconcile(store, action, client))
            console.print("Status checked. No publish request was repeated.")
    finally:
        client.close()


def menu(store):
    while True:
        console.print(
            "\nIGManager\n1 Post images\n2 Manage accounts\n3 Check connection\n4 History\n5 Settings\n6 Check pending post\n0 Exit"
        )
        try:
            choice = input("> ").strip()
            if choice == "0":
                return
            if choice == "1":
                account = choose_account(store)
                paths = image_prompt()
                post(store, account, paths, multiline())
            elif choice == "2":
                account_menu(store)
            elif choice == "3":
                check(store, choose_account(store))
            elif choice == "4":
                history(store)
            elif choice == "5":
                configure(store)
            elif choice == "6":
                reconcile_action(store, input("Action ID from history: ").strip())
        except (ValueError, OSError, sqlite3.Error) as error:
            console.print(f"Error: {error}")
        except KeyboardInterrupt:
            console.print("\nCancelled. Check history if publishing had started.")


def parser():
    p = argparse.ArgumentParser(description="Publish local images to Instagram")
    commands = p.add_subparsers(dest="command")
    commands.add_parser("menu")
    a = commands.add_parser("accounts").add_subparsers(dest="operation", required=True)
    add = a.add_parser("add")
    add.add_argument("name")
    add.add_argument("--ig-id", required=True)
    add.add_argument("--token-file")
    a.add_parser("list")
    edit = a.add_parser("edit")
    edit.add_argument("account")
    edit.add_argument("--name")
    edit.add_argument("--info")
    token = a.add_parser("token")
    token.add_argument("account")
    token.add_argument("--token-file")
    remove = a.add_parser("remove")
    remove.add_argument("account")
    remove.add_argument("--yes", action="store_true")
    status = commands.add_parser("status")
    status.add_argument("account")
    post_parser = commands.add_parser("post")
    post_parser.add_argument("account")
    post_parser.add_argument("images", nargs="+", type=Path)
    captions = post_parser.add_mutually_exclusive_group()
    captions.add_argument("--caption", default="")
    captions.add_argument("--caption-file", type=Path)
    post_parser.add_argument(
        "--yes",
        action="store_true",
        help="Confirm hosting, git push and Instagram publishing",
    )
    hist = commands.add_parser("history")
    hist.add_argument("--account")
    config = commands.add_parser("configure")
    config.add_argument("--repo", type=Path)
    config.add_argument("--hosting-url")
    config.add_argument("--api-version")
    rec = commands.add_parser("reconcile")
    rec.add_argument("action_id")
    return p


def main():
    args = parser().parse_args()
    try:
        with Store() as store:
            if args.command in {None, "menu"}:
                menu(store)
            elif args.command == "accounts":
                if args.operation == "add":
                    add_account(store, args.name, args.ig_id, args.token_file)
                elif args.operation == "list":
                    list_accounts(store)
                else:
                    account = store.account(args.account)
                    unlock(store)
                    if args.operation == "edit":
                        store.edit(args.account, args.name, args.info)
                    elif args.operation == "token":
                        replace_token(store, account, args.token_file)
                    elif (
                        args.yes
                        or input("Remove account and local history? [y/N]: ").lower()
                        == "y"
                    ):
                        store.remove(args.account)
            elif args.command == "status":
                check(store, store.account(args.account))
            elif args.command == "post":
                caption = (
                    args.caption_file.read_text(encoding="utf-8")
                    if args.caption_file
                    else args.caption
                )
                post(
                    store,
                    store.account(args.account),
                    [p.expanduser() for p in args.images],
                    caption,
                    args.yes,
                )
            elif args.command == "history":
                history(store, args.account)
            elif args.command == "reconcile":
                reconcile_action(store, args.action_id)
            elif args.command == "configure":
                values = {
                    k: getattr(args, k) for k in ("repo", "hosting_url", "api_version")
                }
                for key, value in values.items():
                    if value is not None:
                        store.set_setting(
                            key,
                            str(value.resolve()) if isinstance(value, Path) else value,
                        )
                console.print(json.dumps(settings(store), indent=2))
        return 0
    except (ValueError, OSError, sqlite3.Error) as error:
        console.print(f"Error: {error}")
        return 1
    except (KeyboardInterrupt, EOFError):
        console.print("\nExited. Check history if publishing had started.")
        return 130
