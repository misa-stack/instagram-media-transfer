"""Instagram Graph API: explicit container creation, polling, and publishing."""

import re
import time

import httpx


class GraphClient:
    def __init__(self, token, version="v26.0", *, http=None):
        if not re.fullmatch(r"v\d+\.0", version):
            raise ValueError("API version must look like v26.0.")
        self.token = token
        self.base = f"https://graph.facebook.com/{version}"
        self.http = http or httpx.Client(timeout=40)

    def close(self):
        self.http.close()

    def request(self, method, endpoint, **fields):
        try:
            response = self.http.request(
                method,
                f"{self.base}/{endpoint}",
                headers={"Authorization": f"Bearer {self.token}"},
                **({"params": fields} if method == "GET" else {"data": fields}),
            )
            payload = response.json()
        except (httpx.HTTPError, ValueError):
            raise ValueError(
                "Instagram request failed or timed out; inspect history before retrying."
            ) from None
        if response.is_error or "error" in payload:
            error = payload.get("error", {})
            message = str(error.get("message", "Request rejected")).replace(
                self.token, "[redacted]"
            )
            raise ValueError(
                f"Instagram error {error.get('code', response.status_code)}: {message}"
            )
        return payload

    def profile(self, account):
        if not str(account).isdigit():
            raise ValueError("Instagram account ID must be numeric.")
        return self.request("GET", account, fields="id,username")

    def status(self, container):
        return self.request("GET", container, fields="status_code,status")

    def ready(self, container, timeout=300):
        deadline = time.monotonic() + timeout
        while True:
            status = self.status(container).get("status_code")
            if status == "FINISHED":
                return
            if status in {"ERROR", "EXPIRED", "PUBLISHED"}:
                raise ValueError(f"Container {container}: {status}. Check history.")
            if time.monotonic() >= deadline:
                raise ValueError(
                    f"Container {container} processing timed out. Check history."
                )
            time.sleep(2)

    def create(self, account, urls, caption, save):
        children = []
        for url in urls:
            fields = {"image_url": url}
            if len(urls) > 1:
                fields["is_carousel_item"] = "true"
            else:
                fields["caption"] = caption
            container = self.request("POST", f"{account}/media", **fields)["id"]
            save(container)
            children.append(container)
            self.ready(container)
        if len(urls) == 1:
            return children[0]
        parent = self.request(
            "POST",
            f"{account}/media",
            media_type="CAROUSEL",
            children=",".join(children),
            caption=caption,
        )["id"]
        save(parent)
        self.ready(parent)
        return parent

    def publish(self, account, container):
        return self.request("POST", f"{account}/media_publish", creation_id=container)[
            "id"
        ]

    def permalink(self, media):
        return self.request("GET", media, fields="permalink").get("permalink")
