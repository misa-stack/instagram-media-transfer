"""One-command publishing: image paths followed by a quoted caption."""

import argparse
import sqlite3
import sys
from pathlib import Path

from .cli import console, menu, post
from .storage import Store


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    parser = argparse.ArgumentParser(
        description="Publish images immediately using a saved account. Last argument is the caption.",
        usage='%(prog)s [--account NAME] /absolute/image.png [/absolute/image2.png ...] "Caption"',
        epilog="No arguments opens the setup/menu. This command confirms Git push and Instagram publication; the vault passphrase may still be requested.",
    )
    parser.add_argument(
        "--account", help="Saved account nickname; optional when exactly one is saved"
    )
    parser.add_argument("items", nargs="+", metavar="PATH_OR_CAPTION")
    try:
        if not argv:
            with Store() as store:
                menu(store)
            return 0
        args = parser.parse_args(argv)
        if not 2 <= len(args.items) <= 11:
            parser.error(
                'Provide 1–10 image paths followed by a quoted caption (use "" for an empty caption).'
            )
        with Store() as store:
            if args.account:
                account = store.account(args.account)
            else:
                accounts = store.list_accounts()
                if not accounts:
                    raise ValueError(
                        "No saved account. Run python3 igpost.py without arguments to add one first."
                    )
                if len(accounts) != 1:
                    raise ValueError(
                        "Multiple accounts saved. Select one with --account NAME."
                    )
                account = accounts[0]
            post(
                store,
                account,
                [Path(p).expanduser() for p in args.items[:-1]],
                args.items[-1],
                yes=True,
            )
        return 0
    except (ValueError, OSError, sqlite3.Error) as error:
        console.print(f"Error: {error}")
        return 1
    except (KeyboardInterrupt, EOFError):
        console.print("\nExited. Check history if publishing had started.")
        return 130
