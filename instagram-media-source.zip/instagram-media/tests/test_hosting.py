import subprocess

import httpx
import pytest

from igmanager.hosting import Hosting


def git(root, *args):
    return subprocess.run(
        ["git", "-C", str(root), *args], check=True, capture_output=True, text=True
    ).stdout.strip()


def test_push_only_media(repository):
    root, remote = repository
    (root / "unrelated").write_text("keep me")
    media = root / "media" / "job"
    media.mkdir(parents=True)
    image = media / "01.jpg"
    image.write_bytes(b"JPEG")
    host = Hosting(root, "https://example.com")
    host.push([image])
    assert git(root, "show", "--pretty=", "--name-only", "HEAD") == "media/job/01.jpg"
    assert "unrelated" in git(root, "status", "--short")
    assert git(remote, "rev-parse", "main") == git(root, "rev-parse", "HEAD")


def test_staged_changes_block(repository):
    root, _ = repository
    (root / "readme").write_text("changed")
    git(root, "add", "readme")
    with pytest.raises(ValueError, match="staged"):
        Hosting(root, "https://example.com").preflight()


def test_wait_checks_bytes(repository):
    root, _ = repository
    image = root / "a.jpg"
    image.write_bytes(b"correct")
    responses = iter([b"wrong", b"correct"])
    http = httpx.Client(
        transport=httpx.MockTransport(
            lambda r: httpx.Response(200, content=next(responses))
        )
    )
    host = Hosting(root, "https://example.com", http=http)
    host.wait([image], timeout=1, interval=0)


def test_deploy_timeout(repository):
    root, _ = repository
    image = root / "a.jpg"
    image.write_bytes(b"correct")
    http = httpx.Client(transport=httpx.MockTransport(lambda r: httpx.Response(404)))
    with pytest.raises(ValueError, match="deployment"):
        Hosting(root, "https://example.com", http=http).wait([image], timeout=0)


def test_shared_repository_lock(repository):
    root, _ = repository
    first = Hosting(root, "https://example.com")
    second = Hosting(root, "https://example.com")
    with first.lock(), pytest.raises(ValueError, match="Another"), second.lock():
        pass


def test_local_commit_blocks_post(repository):
    root, _ = repository
    (root / "local-only").write_text("do not push")
    git(root, "add", "local-only")
    git(root, "commit", "-m", "Unrelated local commit")
    with pytest.raises(ValueError, match="differs"):
        Hosting(root, "https://example.com").preflight()
