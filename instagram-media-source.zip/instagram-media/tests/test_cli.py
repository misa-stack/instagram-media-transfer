import httpx
import pytest

from igmanager import cli
from igmanager.graph import GraphClient
from igmanager.storage import Store


def test_discover_repo_from_working_directory(repository):
    root, _ = repository
    child = root / "child"
    child.mkdir()
    assert cli.discover_repo(child) == str(root)


def test_cancel_has_no_side_effects(tmp_path, monkeypatch):
    with Store(tmp_path / "vault") as store:
        monkeypatch.setattr("builtins.input", lambda _: "n")
        cli.post(store, {"page_name": "rpi"}, [], "")
        assert store.history() == []


def test_error_redacts_token():
    client = GraphClient(
        "SECRET",
        http=httpx.Client(
            transport=httpx.MockTransport(
                lambda r: httpx.Response(
                    400, json={"error": {"code": 190, "message": "SECRET expired"}}
                )
            )
        ),
    )
    with pytest.raises(ValueError, match="redacted") as error:
        client.profile("123")
    assert "SECRET" not in str(error.value)


def test_processing_error():
    client = GraphClient(
        "token",
        http=httpx.Client(
            transport=httpx.MockTransport(
                lambda r: httpx.Response(200, json={"status_code": "ERROR"})
            )
        ),
    )
    with pytest.raises(ValueError, match="ERROR"):
        client.ready("container")
