import httpx
import pytest
from PIL import Image

from igmanager.graph import GraphClient
from igmanager.images import prepare
from igmanager.storage import Store, VaultError


def test_vault(tmp_path):
    with Store(tmp_path) as s:
        s.unlock("secret", create=True)
        a = s.add("sensor", "", "123", "rpi", "TOKEN")
        assert s.token(a) == "TOKEN"
        s.edit("sensor", "renamed", "room", token="NEW")
    assert b"TOKEN" not in (tmp_path / "pages.sqlite3").read_bytes()
    with Store(tmp_path) as s:
        with pytest.raises(VaultError):
            s.unlock("wrong")
        s.unlock("secret")
        assert s.token(s.account("renamed")) == "NEW"
        s.remove("renamed")
        assert s.list_accounts() == []


def test_prepare_preserves_graph(tmp_path):
    source = tmp_path / "graph.png"
    Image.new("RGBA", (2000, 300), "red").save(source)
    original = source.read_bytes()
    output = prepare([source], tmp_path / "out")
    with Image.open(output[0]) as im:
        assert im.format == "JPEG"
        assert im.size == (1080, 1080)
        assert im.getpixel((540, 540))[0] > 240
        assert im.getpixel((0, 0)) == (255, 255, 255)
    assert source.read_bytes() == original
    with pytest.raises(ValueError):
        prepare([source] * 11, tmp_path / "other")


@pytest.mark.parametrize("count", [1, 3])
def test_publish_protocol(count):
    requests = []

    def respond(r):
        requests.append(r)
        assert r.headers["Authorization"] == "Bearer TOKEN"
        if r.method == "POST":
            return httpx.Response(200, json={"id": str(len(requests))})
        return httpx.Response(200, json={"status_code": "FINISHED"})

    client = GraphClient(
        "TOKEN", "v26.0", http=httpx.Client(transport=httpx.MockTransport(respond))
    )
    saved = []
    parent = client.create(
        "123", ["https://example.com/a.jpg"] * count, "Český caption", saved.append
    )
    result = client.publish("123", parent)
    assert result
    bodies = [r.content.decode() for r in requests if r.method == "POST"]
    assert ("media_type=CAROUSEL" in "".join(bodies)) == (count > 1)
    assert len(saved) == count + (1 if count > 1 else 0)
    assert requests[-1].url.path.endswith("/media_publish")


def test_bad_path_creates_no_output(tmp_path):
    output = tmp_path / "out"
    with pytest.raises(ValueError, match="absolute"):
        prepare([tmp_path / "missing.png"], output)
    assert not output.exists()
