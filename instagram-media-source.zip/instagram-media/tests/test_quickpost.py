from pathlib import Path
from unittest.mock import Mock

import pytest

from igmanager import quickpost
from igmanager.storage import Store


def test_quickpost_paths_caption_and_single_account(tmp_path, monkeypatch):
    monkeypatch.setenv("IGMANAGER_HOME", str(tmp_path / "data"))
    with Store() as store:
        store.unlock("pass", create=True)
        store.add("sensor", "", "123", "rpi", "token")
    post = Mock()
    monkeypatch.setattr(quickpost, "post", post)
    assert (
        quickpost.main(["/tmp/one graph.png", "/tmp/two.png", "Temperature today"]) == 0
    )
    args = post.call_args.args
    assert args[1]["name"] == "sensor"
    assert args[2] == [Path("/tmp/one graph.png"), Path("/tmp/two.png")]
    assert args[3] == "Temperature today"
    assert post.call_args.kwargs["yes"] is True


def test_multiple_accounts_require_explicit_choice(tmp_path, monkeypatch):
    monkeypatch.setenv("IGMANAGER_HOME", str(tmp_path / "data"))
    with Store() as store:
        store.unlock("pass", create=True)
        store.add("first", "", "123", "rpi", "token")
        store.add("second", "", "456", "other", "token")
    post = Mock()
    monkeypatch.setattr(quickpost, "post", post)
    assert quickpost.main(["/tmp/one.png", "Caption"]) == 1
    post.assert_not_called()
    assert quickpost.main(["--account", "second", "/tmp/one.png", "Caption"]) == 0
    assert post.call_args.args[1]["name"] == "second"


def test_caption_required():
    with pytest.raises(SystemExit) as error:
        quickpost.main(["/tmp/image.png"])
    assert error.value.code == 2


def test_no_arguments_opens_menu(tmp_path, monkeypatch):
    monkeypatch.setenv("IGMANAGER_HOME", str(tmp_path / "data"))
    menu = Mock()
    monkeypatch.setattr(quickpost, "menu", menu)
    assert quickpost.main([]) == 0
    menu.assert_called_once()
