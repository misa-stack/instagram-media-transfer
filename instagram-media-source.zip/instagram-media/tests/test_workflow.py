from pathlib import Path
from unittest.mock import Mock

import pytest

from igmanager.storage import Store
from igmanager.workflow import publish, reconcile


def test_uncertain_publish_retained(tmp_path):
    with Store(tmp_path / "vault") as store:
        store.unlock("pass", create=True)
        account = store.add("rpi", "", "123", "rpi", "token")
        graph = Mock()
        graph.create.side_effect = lambda a, u, c, save: (
            save("container"),
            "container",
        )[1]
        graph.publish.side_effect = ValueError("timeout")
        host = Mock()
        host.urls.return_value = ["https://example.com/image.jpg"]
        with pytest.raises(ValueError):
            publish(store, account, [Path("/image")], "caption", host, graph)
        action = store.history()[0]
        assert action["status"] == "publish_uncertain"
        assert action["result"]["parent"] == "container"
        graph.status.return_value = {"status_code": "PUBLISHED"}
        reconcile(store, action, graph)
        assert store.history()[0]["status"] == "published"
        assert graph.publish.call_count == 1


def test_hosting_failure_never_publishes(tmp_path):
    with Store(tmp_path / "vault") as store:
        store.unlock("pass", create=True)
        account = store.add("rpi", "", "123", "rpi", "token")
        host, graph = Mock(), Mock()
        host.push.side_effect = ValueError("push failed")
        with pytest.raises(ValueError):
            publish(store, account, [Path("/image")], "", host, graph)
        graph.create.assert_not_called()
        assert store.history()[0]["status"] == "failed"


def test_interrupt_after_publish_stays_published(tmp_path):
    with Store(tmp_path / "vault") as store:
        store.unlock("pass", create=True)
        account = store.add("rpi", "", "123", "rpi", "token")
        host, graph = Mock(), Mock()
        host.urls.return_value = ["https://example.com/image.jpg"]
        graph.create.return_value = "container"
        graph.publish.return_value = "media"
        graph.permalink.side_effect = KeyboardInterrupt()
        with pytest.raises(KeyboardInterrupt):
            publish(store, account, [Path("/image")], "", host, graph)
        assert store.history()[0]["status"] == "published"
        assert store.history()[0]["result"]["media_id"] == "media"
