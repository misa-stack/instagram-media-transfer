# Raspberry Pi Zero: one-file Instagram publisher

Only `igpost.py` is needed. It uses Python's standard library and the Git command.
No pip, uv, virtual environment, encryption, or vault passphrase is required.
The previous encrypted application in src/ is optional and is not used by this script.

## One-time setup on Raspberry Pi OS

Copy igpost.py into your Pi's home folder, then run:

```sh
sudo apt update
sudo apt install -y python3 git gh ca-certificates

gh auth login --hostname github.com --git-protocol https --web
gh auth setup-git

git clone https://github.com/misa-stack/instagram-media.git ~/instagram-hosting
git -C ~/instagram-hosting config user.name "Sensor Pi"
git -C ~/instagram-hosting config user.email "sensor@localhost"

python3 ~/igpost.py --setup
```

Follow GitHub's browser login instructions; the URL can be opened on another
computer. The local Git identity labels automated commits and can be replaced
with your own name and email.

Press Enter to accept the default Instagram ID, repository path, Cloudflare URL
and API version. Paste your working System User token when asked. It is stored
as plain text in `~/.config/igpost/config.txt`, outside the public Git repository.
Run --setup again to change it, or edit that text file directly (JSON format).
No migration from the old encrypted vault is needed: simply paste the token again.

## Post

```sh
python3 ~/igpost.py /absolute/path/temperature.jpg "Temperature today"
python3 ~/igpost.py /absolute/path/temp.jpg /absolute/path/humidity.jpg "Today's readings"
```

The last argument is always the caption. Quote it; use "" for no caption.
One image makes a normal post; 2–10 create a carousel in the order entered.
The command immediately commits the selected images, pushes to GitHub, waits for
Cloudflare Pages, then publishes. No further prompts occur after setup.
Run `python3 ~/igpost.py` for the small Post / Setup / Status menu instead.

Supply ready-to-post JPEG files (up to 8 MB each, aspect ratio 4:5 through 1.91:1).
Square JPEGs are simplest for carousels. The script copies images unchanged,
including their metadata; it does not decode, resize or convert them. If your
sensor script uses matplotlib, save directly as JPEG:

```python
plt.savefig('/home/YOUR_PI_USER/temperature.jpg', format='jpg', dpi=150)
```

Git must be on main, with no staged changes and no local commits ahead of
origin/main. The tool commits only selected images under media/<unique-id>/.
It preserves unrelated unstaged files, does not merge or force-push, and leaves
hosted images in place. The existing Cloudflare Pages integration must deploy
origin/main with the repository root as output directory.

## Check a timeout

```sh
python3 ~/igpost.py --status
```

A timeout during the final publish step blocks a new post until --status confirms
PUBLISHED. If status remains uncertain, check Instagram manually first. After
checking, `python3 ~/igpost.py --forget-pending` lets you clear the pending flag.
It does not publish anything. Last progress is stored in
`~/.config/igpost/last_post.txt`; IGPOST_HOME can override the config directory.

Runtime checks use streamed image hashing and JPEG headers rather than decoded
pixel buffers. Raspberry Pi Zero hardware and live Instagram publishing have
not been tested here; automated tests use mocked Meta responses and local Git.
