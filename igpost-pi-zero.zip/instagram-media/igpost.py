#!/usr/bin/env python3
"""Pi Zero Instagram publisher. Python standard library + git; no pip required."""

import argparse
import fcntl
import getpass
import hashlib
import json
import os
import re
import shutil
import struct
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from contextlib import contextmanager
from pathlib import Path
from uuid import uuid4

HOME = Path(
    os.environ.get("IGPOST_HOME", str(Path.home() / ".config/igpost"))
).expanduser()


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temporary = path.with_suffix(".tmp")
    fd = os.open(temporary, os.O_CREAT | os.O_TRUNC | os.O_WRONLY, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as stream:
        json.dump(data, stream, indent=2, ensure_ascii=False)
    temporary.replace(path)


def setup():
    path = HOME / "config.txt"
    old = read_json(path) if path.exists() else {}
    config = {}
    for key, label, default in [
        ("ig_id", "Instagram account ID", "17841437005937020"),
        ("repo", "Git image repository", str(Path.home() / "instagram-hosting")),
        ("hosting_url", "Cloudflare URL", "https://instagram-media.pages.dev"),
        ("api_version", "Graph API version", "v26.0"),
    ]:
        default = old.get(key, default)
        config[key] = input(f"{label} [{default}]: ").strip() or default
    config["token"] = getpass.getpass(
        "Token (Enter keeps saved token): "
    ).strip() or old.get("token", "")
    validate_config(config)
    write_json(path, config)
    print(f"Saved plaintext settings and token in {path}")


def validate_config(config):
    if not config.get("token") or not str(config.get("ig_id", "")).isdigit():
        raise ValueError("Set a token and numeric Instagram account ID with --setup.")
    if not re.fullmatch(r"v\d+\.0", config.get("api_version", "")):
        raise ValueError("API version must look like v26.0.")
    if urllib.parse.urlparse(config.get("hosting_url", "")).scheme != "https":
        raise ValueError("Cloudflare URL must start with https://.")


def load_config():
    path = HOME / "config.txt"
    if not path.exists():
        raise ValueError("Run python3 igpost.py --setup first.")
    config = read_json(path)
    validate_config(config)
    return config


@contextmanager
def lock(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a") as stream:
        try:
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise ValueError(
                "Another igpost command is running. Wait for it to finish."
            ) from None
        yield


def api(config, method, endpoint, **fields):
    url = f"https://graph.facebook.com/{config['api_version']}/{endpoint}"
    encoded = urllib.parse.urlencode(fields).encode()
    if method == "GET":
        url += "?" + encoded.decode()
    request = urllib.request.Request(
        url,
        data=encoded if method == "POST" else None,
        headers={"Authorization": "Bearer " + config["token"]},
        method=method,
    )
    try:
        with urllib.request.urlopen(request, timeout=40) as response:
            result = json.load(response)
    except urllib.error.HTTPError as error:
        try:
            message = (
                json.load(error).get("error", {}).get("message", "Request rejected")
            )
        except (ValueError, AttributeError):
            message = "Request rejected"
        raise ValueError(
            f"Instagram: {message}".replace(config["token"], "[token]")
        ) from None
    except (OSError, ValueError):
        raise ValueError(
            "Instagram connection failed. If publishing started, check --status before retrying."
        ) from None
    if not isinstance(result, dict) or "error" in result:
        raise ValueError("Instagram returned an unexpected response.")
    return result


def git(repo, *args):
    result = subprocess.run(
        ["git", "-C", str(repo), *args], check=False, capture_output=True, text=True
    )
    if result.returncode:
        raise ValueError(
            f"Git {args[0]} failed. Check repository, Git identity and GitHub authentication."
        )
    return result.stdout.strip()


def jpeg_size(path):
    # Read marker headers only; never decode image pixels on the Pi.
    with path.open("rb") as stream:
        if stream.read(2) != b"\xff\xd8":
            raise ValueError(f"{path.name}: use a JPEG image, not PNG or WebP.")
        while True:
            prefix = stream.read(1)
            if prefix != b"\xff":
                break
            marker = stream.read(1)
            while marker == b"\xff":
                marker = stream.read(1)
            if not marker or marker in {b"\xd9", b"\xda"}:
                break
            length_bytes = stream.read(2)
            if len(length_bytes) != 2:
                break
            length = struct.unpack(">H", length_bytes)[0]
            if length < 2:
                break
            if marker in {bytes([m]) for m in (0xC0, 0xC1, 0xC2)}:
                header = stream.read(5)
                if len(header) == 5:
                    height, width = struct.unpack(">HH", header[1:])
                    return width, height
                break
            stream.seek(length - 2, 1)
    raise ValueError(f"{path.name}: invalid or unsupported JPEG.")


def validate_images(names):
    if not 1 <= len(names) <= 10:
        raise ValueError("Choose 1–10 JPEG images.")
    paths = []
    for name in names:
        path = Path(name).expanduser().resolve()
        if not path.is_file() or path.stat().st_size > 8 * 1024 * 1024:
            raise ValueError(f"Image missing or larger than 8 MB: {path}")
        width, height = jpeg_size(path)
        if height == 0 or not 0.8 <= width / height <= 1.91:
            raise ValueError(
                f"{path.name}: use a JPEG with aspect ratio 4:5 through 1.91:1 (square is simplest)."
            )
        paths.append(path)
    return paths


def host_images(config, images):
    repo = Path(config["repo"]).expanduser().resolve()
    git_dir = Path(git(repo, "rev-parse", "--absolute-git-dir"))
    with lock(git_dir / "igpost.lock"):
        if git(repo, "branch", "--show-current") != "main":
            raise ValueError("Image repository must be on main.")
        if git(repo, "diff", "--cached", "--name-only"):
            raise ValueError("Commit or unstage existing staged changes first.")
        print("Checking GitHub…", flush=True)
        git(repo, "fetch", "origin", "main")
        if git(repo, "rev-parse", "HEAD") != git(repo, "rev-parse", "origin/main"):
            raise ValueError(
                "Local main differs from origin/main. Synchronize it manually first."
            )
        directory = repo / "media" / uuid4().hex
        directory.mkdir(parents=True)
        paths = []
        for index, source in enumerate(images, 1):
            target = directory / f"{index:02}.jpg"
            shutil.copyfile(source, target)
            paths.append(target)
        relative = [p.relative_to(repo).as_posix() for p in paths]
        git(repo, "add", "--", *relative)
        git(repo, "commit", "-m", "Add Instagram images", "--", *relative)
        git(repo, "push", "origin", "HEAD:main")
    urls = [config["hosting_url"].rstrip("/") + "/" + p for p in relative]
    return paths, urls


def digest(stream):
    result = hashlib.sha256()
    for block in iter(lambda: stream.read(65536), b""):
        result.update(block)
    return result.digest()


def wait_hosting(paths, urls):
    print("Waiting for Cloudflare…", flush=True)
    pending = {}
    for path, url in zip(paths, urls):
        with path.open("rb") as stream:
            pending[url] = digest(stream)
    deadline = time.monotonic() + 600
    while pending:
        for url, expected in list(pending.items()):
            try:
                with urllib.request.urlopen(url, timeout=20) as response:
                    if digest(response) == expected:
                        del pending[url]
            except OSError:
                pass
        if not pending:
            return
        if time.monotonic() >= deadline:
            raise ValueError(
                "Cloudflare deployment timed out. No Instagram post was published."
            )
        time.sleep(5)


def ready(config, container):
    deadline = time.monotonic() + 300
    while True:
        status = api(config, "GET", container, fields="status_code")["status_code"]
        if status == "FINISHED":
            return
        if status in {"ERROR", "EXPIRED"} or time.monotonic() >= deadline:
            raise ValueError(f"Container {container}: {status}; not published.")
        time.sleep(3)


def ensure_no_pending():
    path = HOME / "last_post.txt"
    if path.exists() and read_json(path).get("status") == "publishing":
        raise ValueError(
            "Previous publication is uncertain. Run --status before another post."
        )


def publish(config, urls, caption):
    state = {"status": "preparing", "containers": []}
    path = HOME / "last_post.txt"
    write_json(path, state)
    for url in urls:
        fields = {"image_url": url}
        fields.update(
            {"is_carousel_item": "true"} if len(urls) > 1 else {"caption": caption}
        )
        container = api(config, "POST", config["ig_id"] + "/media", **fields)["id"]
        state["containers"].append(container)
        write_json(path, state)
        ready(config, container)
    parent = state["containers"][0]
    if len(urls) > 1:
        parent = api(
            config,
            "POST",
            config["ig_id"] + "/media",
            media_type="CAROUSEL",
            children=",".join(state["containers"]),
            caption=caption,
        )["id"]
        ready(config, parent)
    state.update(parent=parent, status="publishing")
    write_json(path, state)
    print("Publishing…", flush=True)
    media_id = api(
        config, "POST", config["ig_id"] + "/media_publish", creation_id=parent
    )["id"]
    state.update(status="published", media_id=media_id)
    write_json(path, state)
    print("Published! Post ID:", media_id)


def status(config):
    path = HOME / "last_post.txt"
    if not path.exists():
        print("No previous post.")
        return
    state = read_json(path)
    if state.get("status") == "publishing":
        result = api(config, "GET", state["parent"], fields="status_code")
        if result.get("status_code") == "PUBLISHED":
            state["status"] = "published"
            write_json(path, state)
        print("Instagram container:", result.get("status_code"))
    print(json.dumps(state, indent=2))


def run_post(config, names, caption):
    ensure_no_pending()
    images = validate_images(names)
    if len(caption) > 2200:
        raise ValueError("Caption exceeds 2,200 characters.")
    api(config, "GET", config["ig_id"], fields="id,username")
    paths, urls = host_images(config, images)
    wait_hosting(paths, urls)
    publish(config, urls, caption)


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Pi Zero Instagram publisher: no pip packages required."
    )
    actions = parser.add_mutually_exclusive_group()
    actions.add_argument(
        "--setup", action="store_true", help="Save account and plaintext token"
    )
    actions.add_argument(
        "--status",
        action="store_true",
        help="Check the last post without publishing again",
    )
    actions.add_argument(
        "--forget-pending",
        action="store_true",
        help="Clear uncertain post after manually checking Instagram",
    )
    parser.add_argument(
        "items", nargs="*", help="JPEG paths followed by a quoted caption"
    )
    args = parser.parse_args(argv)
    try:
        with lock(HOME / "command.lock"):
            if args.setup:
                setup()
            elif args.status:
                status(load_config())
            elif args.forget_pending:
                if (
                    input(
                        "Have you checked Instagram for the previous post? Type yes: "
                    )
                    == "yes"
                ):
                    write_json(HOME / "last_post.txt", {"status": "manually_cleared"})
            elif args.items:
                if len(args.items) < 2:
                    parser.error(
                        'Provide JPEG path(s) followed by a quoted caption; use "" for no caption.'
                    )
                run_post(load_config(), args.items[:-1], args.items[-1])
            else:
                while True:
                    choice = input(
                        "\n1 Post images\n2 Setup / change token\n3 Last post status\n0 Exit\n> "
                    ).strip()
                    if choice == "0":
                        break
                    if choice == "2":
                        setup()
                    elif choice == "3":
                        status(load_config())
                    elif choice == "1":
                        names = []
                        print("JPEG paths, one per line. Empty line finishes.")
                        while True:
                            name = input("Image: ").strip()
                            if not name:
                                break
                            names.append(name.strip("\"'"))
                        run_post(load_config(), names, input("Caption: "))
        return 0
    except (ValueError, OSError, KeyError) as error:
        print("Error:", error, file=sys.stderr)
        return 1
    except (KeyboardInterrupt, EOFError):
        print(
            "\nStopped. If publishing had started, check --status before retrying.",
            file=sys.stderr,
        )
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
